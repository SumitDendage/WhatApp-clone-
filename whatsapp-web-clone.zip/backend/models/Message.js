const mongoose = require('mongoose');
const MessageSchema = new mongoose.Schema({
  msg_id: { type: String, index: true },
  meta_msg_id: { type: String, index: true },
  wa_id: { type: String, index: true },
  from: String,
  to: String,
  direction: { type: String, enum: ['incoming','outgoing'], default: 'incoming' },
  text: String,
  type: String,
  timestamp: { type: Date, default: Date.now },
  status: { type: String, enum: ['sent','delivered','read','unknown'], default: 'unknown' },
  raw: Object
});
module.exports = mongoose.model('Message', MessageSchema);
