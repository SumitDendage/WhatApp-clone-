const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
router.post('/webhook', async (req, res) => {
  const payload = req.body;
  try {
    if (Array.isArray(payload)) {
      for (const p of payload) await processPayload(p, req.io);
    } else {
      await processPayload(payload, req.io);
    }
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: String(err) });
  }
});
async function processPayload(p, io) {
  if (!p) return;
  if (p.messages && Array.isArray(p.messages)) {
    for (const m of p.messages) {
      const doc = {
        msg_id: m.id || m.message_id || m.msg_id,
        meta_msg_id: m.context?.id || m.context?.message_id || null,
        wa_id: m.from || m.sender?.wa_id || m.wa_id || m.to || 'unknown',
        from: m.from || m.sender?.wa_id || null,
        to: m.to || m.receiver || null,
        direction: m.from ? 'incoming' : 'outgoing',
        text: m.text?.body || m.body || (m.type === 'text' && m.content) || '',
        type: m.type || 'text',
        timestamp: m.timestamp ? new Date(m.timestamp * 1000) : new Date(),
        status: m.status || 'sent',
        raw: m
      };
      const existing = await Message.findOne({ msg_id: doc.msg_id }).exec();
      if (!existing) {
        const created = await Message.create(doc);
        if (io) io.emit('message:new', created);
      }
    }
  }
  if (p.statuses && Array.isArray(p.statuses)) {
    for (const s of p.statuses) {
      const q = s.id ? { msg_id: s.id } : (s.meta_msg_id ? { meta_msg_id: s.meta_msg_id } : null);
      if (!q) continue;
      const msg = await Message.findOne(q).exec();
      if (msg) {
        msg.status = s.status || msg.status;
        await msg.save();
        if (io) io.emit('message:update', msg);
      }
    }
  }
}
router.get('/conversations', async (req, res) => {
  const agg = await Message.aggregate([
    { $sort: { timestamp: -1 } },
    { $group: { _id: '$wa_id', last: { $first: '$$ROOT' }, count: { $sum: 1 } } },
    { $project: { wa_id: '$_id', last: 1, count: 1, _id: 0 } },
    { $sort: { 'last.timestamp': -1 } }
  ]).exec();
  res.json(agg);
});
router.get('/conversations/:wa_id/messages', async (req, res) => {
  const wa_id = req.params.wa_id;
  const messages = await Message.find({ wa_id }).sort({ timestamp: 1 }).exec();
  res.json(messages);
});
router.post('/conversations/:wa_id/send', async (req, res) => {
  const wa_id = req.params.wa_id;
  const { text } = req.body;
  const outgoing = {
    msg_id: 'local-' + Date.now() + '-' + Math.random().toString(36).slice(2,8),
    meta_msg_id: null,
    wa_id,
    from: 'me',
    to: wa_id,
    direction: 'outgoing',
    text,
    type: 'text',
    timestamp: new Date(),
    status: 'sent',
    raw: { local: true }
  };
  const doc = await Message.create(outgoing);
  if (req.io) req.io.emit('message:new', doc);
  res.json(doc);
});
module.exports = router;
