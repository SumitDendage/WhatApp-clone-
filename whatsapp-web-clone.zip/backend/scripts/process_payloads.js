require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const Message = require('../models/Message');
const PAYLOAD_DIR = path.join(__dirname, '..', 'payloads');
async function main(){
  await mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('Connected to Mongo');
  const files = fs.existsSync(PAYLOAD_DIR) ? fs.readdirSync(PAYLOAD_DIR).filter(f => f.endsWith('.json')) : [];
  for (const file of files){
    const content = JSON.parse(fs.readFileSync(path.join(PAYLOAD_DIR, file), 'utf8'));
    await handlePayload(content);
    console.log('Processed', file);
  }
  console.log('Done');
  process.exit(0);
}
async function handlePayload(p){
  if (Array.isArray(p)) { for (const e of p) await handlePayload(e); return; }
  if (p.messages && Array.isArray(p.messages)){
    for (const m of p.messages){
      const msgId = m.id || m.message_id || m.msg_id;
      const query = { msg_id: msgId };
      const doc = {
        msg_id: msgId,
        meta_msg_id: m.meta_msg_id || m.context?.id || null,
        wa_id: m.from || m.sender?.wa_id || m.wa_id || m.to || 'unknown',
        from: m.from || m.sender?.wa_id || null,
        to: m.to || m.receiver || null,
        direction: m.from ? 'incoming' : 'outgoing',
        text: m.text?.body || m.body || '',
        type: m.type || 'text',
        timestamp: m.timestamp ? new Date(m.timestamp * 1000) : new Date(),
        status: m.status || 'sent',
        raw: m
      };
      const existing = await Message.findOne(query);
      if (!existing){
        await Message.create(doc);
      }
    }
  }
  if (p.statuses && Array.isArray(p.statuses)){
    for (const s of p.statuses){
      const q = s.id ? { msg_id: s.id } : (s.meta_msg_id ? { meta_msg_id: s.meta_msg_id } : null);
      if (!q) continue;
      const m = await Message.findOne(q);
      if (m){
        m.status = s.status || m.status;
        await m.save();
      }
    }
  }
}
main().catch(err => { console.error(err); process.exit(1); });
