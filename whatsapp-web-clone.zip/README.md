  # WhatsApp Web–Like Clone

This repo contains a Node.js (Express + Mongoose) backend and a React frontend that mimic WhatsApp Web.

## Quick start (local)
1. Create a MongoDB Atlas cluster or run MongoDB locally and copy the connection string into `backend/.env` (use `.env.example` as reference).
2. Place your sample webhook JSON files into `backend/payloads/`.
3. From `backend/`:
   ```bash
   npm install
   npm run process-payloads # optional - to ingest payload JSONs into MongoDB
   npm run dev
   ```
4. From `frontend/`:
   ```bash
   npm install
   npm start
   ```

## Docker
Run `docker-compose up --build` (make sure `backend/.env` contains `MONGODB_URI`).

## Deployment
- Backend: Render/Heroku (set MONGODB_URI env var)
- Frontend: Vercel/Netlify (set REACT_APP_API_URL)

## Notes
- Webhook endpoint: POST /api/webhook
- Conversations: GET /api/conversations
- Conversation messages: GET /api/conversations/:wa_id/messages
- Send (store only): POST /api/conversations/:wa_id/send
