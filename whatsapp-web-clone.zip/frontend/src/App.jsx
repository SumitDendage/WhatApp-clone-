import React, { useState, useEffect } from 'react';
import { fetchConversations } from './api';
import ChatList from './components/ChatList';
import ChatWindow from './components/ChatWindow';
import { io } from 'socket.io-client';
const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:4000';
export default function App(){
  const [conversations, setConversations] = useState([]);
  const [active, setActive] = useState(null);
  const [socket, setSocket] = useState(null);
  useEffect(()=>{ load(); const s = io(SOCKET_URL); s.on('connect', ()=>console.log('socket connected')); s.on('message:new', (m) => { setConversations(prev => { const copy = prev.filter(c => c.wa_id !== m.wa_id); const entry = { wa_id: m.wa_id, last: m, count: (prev.find(p=>p.wa_id===m.wa_id)?.count||0)+1 }; return [entry, ...copy]; }); }); s.on('message:update', (m) => { setConversations(prev => prev.map(c => c.wa_id === m.wa_id ? { ...c, last: m } : c)); }); setSocket(s); return ()=> s.disconnect(); }, []);
  async function load(){ const conv = await fetchConversations(); setConversations(conv); if (conv.length && !active) setActive(conv[0].wa_id); }
  return (
    <div className="app-root">
      <aside className="sidebar">
        <header className="sidebar-header">WhatsApp Clone</header>
        <ChatList conversations={conversations} onSelect={setActive} active={active} />
      </aside>
      <main className="main">
        {active ? <ChatWindow wa_id={active} socket={socket} /> : <div className="empty">Select a conversation</div>}
      </main>
    </div>
  );
}
