import React from 'react';
export default function ChatList({ conversations, onSelect, active }){
  return (
    <div className="chat-list">
      {conversations.map(c => (
        <div key={c.wa_id} className={"chat-item " + (active === c.wa_id ? 'active':'')} onClick={()=>onSelect(c.wa_id)}>
          <div className="avatar">{c.wa_id?.slice(-2)}</div>
          <div className="meta">
            <div className="name">{c.wa_id}</div>
            <div className="last">{c.last?.text?.slice(0, 40) || '—'}</div>
          </div>
          <div className="time">{c.last ? new Date(c.last.timestamp).toLocaleTimeString() : ''}</div>
        </div>
      ))}
    </div>
  );
}
