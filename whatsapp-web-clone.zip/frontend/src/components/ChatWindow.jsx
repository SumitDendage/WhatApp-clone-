import React, { useState, useEffect, useRef } from 'react';
import { fetchMessages, sendMessage } from '../api';
export default function ChatWindow({ wa_id, socket }){
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const boxRef = useRef();
  useEffect(()=>{ load(); const handlerNew = (m) => { if (m.wa_id === wa_id){ setMessages(prev=>[...prev, m]); scrollBottom(); }}; const handlerUpd = (m) => { if (m.wa_id === wa_id){ setMessages(prev => prev.map(x => x.msg_id === m.msg_id ? m : x)); }}; if (socket){ socket.on('message:new', handlerNew); socket.on('message:update', handlerUpd); } return ()=>{ if (socket){ socket.off('message:new', handlerNew); socket.off('message:update', handlerUpd); } } }, [wa_id, socket]);
  async function load(){ const msgs = await fetchMessages(wa_id); setMessages(msgs); scrollBottom(); }
  function scrollBottom(){ setTimeout(()=>{ if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight }, 50); }
  async function handleSend(e){ e.preventDefault(); if (!text.trim()) return; const created = await sendMessage(wa_id, text.trim()); setMessages(prev => [...prev, created]); setText(''); scrollBottom(); }
  return (
    <div className="chat-window">
      <div className="chat-header">{wa_id}</div>
      <div className="messages" ref={boxRef}>
        {messages.map(m => (
          <div key={m.msg_id} className={"bubble " + (m.direction === 'outgoing' ? 'out':'in')}>
            <div className="text">{m.text}</div>
            <div className="meta">
              <span className="time">{new Date(m.timestamp).toLocaleString()}</span>
              <span className="status">{m.status}</span>
            </div>
          </div>
        ))}
      </div>
      <form className="composer" onSubmit={handleSend}>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message" />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
