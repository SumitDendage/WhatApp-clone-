const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';
export async function fetchConversations(){ const r = await fetch(API + '/conversations'); return r.json(); }
export async function fetchMessages(wa_id){ const r = await fetch(API + '/conversations/' + encodeURIComponent(wa_id) + '/messages'); return r.json(); }
export async function sendMessage(wa_id, text){ const r = await fetch(API + '/conversations/' + encodeURIComponent(wa_id) + '/send', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) }); return r.json(); }
